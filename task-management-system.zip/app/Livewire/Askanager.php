<?php

namespace App\Livewire;

use Livewire\Component;

class Askanager extends Component
{
    public function render()
    {
        return view('livewire.askanager');
    }
}
